# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Window Maker",
    "author" : "Blender Bash", 
    "description" : "Create Multiple Windows with just a click",
    "blender" : (4, 2, 0),
    "version" : (2, 1, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
level_00_panel__mode = {'sna_exists': None, }
level_07_extras = {'sna_stored_uv_attr': '', }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


class RENDER_PT_Window(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'RENDER_PT_Window'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Windows'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (( not 'OBJECT'==bpy.context.mode if (bpy.context.view_layer.objects.active != None) else True))

    def draw_header(self, context):
        layout = self.layout
        layout.label(text='Windows', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'BB_logo48.png')))

    def draw(self, context):
        layout = self.layout


class SNA_OT_Make_Win_Unique_Operator_2Bf2A(bpy.types.Operator):
    bl_idname = "sna.make_win_unique_operator_2bf2a"
    bl_label = "Make Win unique Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.ops.object.geometry_node_tree_copy_assign('INVOKE_DEFAULT', )
        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT', )
        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clear_bool_object_function_5A0FF(Wall_object):
    if (bpy.context.scene.sna_help_bool_counter == 0):
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = Wall_object
        if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'BB.GeometryNodesBoolean' in bpy.context.active_object.modifiers):
            if (Wall_object.modifiers['BB.GeometryNodesBoolean']['Input_2'] != None):
                bpy.context.scene.sna_stored_bool_object = Wall_object.modifiers['BB.GeometryNodesBoolean']['Input_2']
                bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_bool_object
                bpy.context.scene.sna_stored_bool_object.hide_render = False
                bpy.context.scene.sna_stored_bool_object.hide_viewport = False
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.scene.sna_stored_bool_object.select_set(state=True, )
                bpy.ops.object.delete(use_global=True)
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.scene.sna_help_bool_counter = int(bpy.context.scene.sna_help_bool_counter + 1.0)


def sna_clear_single_wall_bool_modifier_16E52(Wall_object):
    bpy.context.view_layer.objects.active = Wall_object
    if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'BB.GeometryNodesBoolean' in bpy.context.active_object.modifiers):
        bpy.ops.object.modifier_remove('INVOKE_DEFAULT', modifier='BB.GeometryNodesBoolean')


def sna_function_create_holes_2E568(Wall_Object):
    bpy.context.scene.sna_stored_wall_object = None
    bpy.context.scene.sna_stored_wall_object = Wall_Object
    bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_wall_object
    bpy.ops.object.modifier_add(type='NODES')
    bpy.context.active_object.modifiers.active.name = 'BB.GeometryNodesBoolean'
    bpy.context.active_object.modifiers['BB.GeometryNodesBoolean'].node_group = bpy.context.blend_data.node_groups['BB.Bools.Geonode']
    bpy.context.view_layer.objects.active.modifiers['BB.GeometryNodesBoolean']['Input_2'] = bpy.context.scene.sna_stored_bool_object


def sna_function_create_bbboolsgeonode_02341():
    bpy.ops.mesh.primitive_ico_sphere_add('INVOKE_DEFAULT', )
    bpy.context.scene.sna_stored_help_object = bpy.context.view_layer.objects.active
    if (property_exists("bpy.data.node_groups", globals(), locals()) and 'BB.Bools.Geonode' in bpy.data.node_groups):
        pass
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'TotalWindows.4.0.blend') + r'\NodeTree', filename='BB.Bools.Geonode', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_F0DF4 = None if not new_data else new_data[0]
    bpy.context.view_layer.objects.active.select_set(state=True, )
    bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='NODES')
    bpy.context.active_object.modifiers.active.name = 'Bool Object'
    bpy.context.active_object.modifiers.active.node_group = bpy.data.node_groups[bpy.data.node_groups.find('BB.Bools.Geonode')]
    if (property_exists("bpy.data.node_groups", globals(), locals()) and 'BB.Bool.Walls' in bpy.data.node_groups):
        pass
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'TotalWindows.4.0.blend') + r'\NodeTree', filename='BB.Bool.Walls', link=True)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_EB734 = None if not new_data else new_data[0]
    bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group'].node_tree = bpy.data.node_groups[bpy.data.node_groups.find('BB.Bool.Walls')]
    link_33C6B = bpy.data.node_groups['BB.Bools.Geonode'].links.new(input=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group'].outputs[0], output=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group Output'].inputs[0], )
    link_C83B2 = bpy.data.node_groups['BB.Bools.Geonode'].links.new(input=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group Input'].outputs[0], output=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group'].inputs[0], )
    link_C0EE4 = bpy.data.node_groups['BB.Bools.Geonode'].links.new(input=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group Input'].outputs[1], output=bpy.data.node_groups['BB.Bools.Geonode'].nodes['Group'].inputs[1], )
    bpy.data.node_groups.remove(tree=bpy.data.node_groups[bpy.data.node_groups.find('BB.help.windows')], )
    bpy.context.scene.sna_stored_help_object.select_set(state=True, )
    bpy.ops.object.delete()


def sna_create_bool_object_from_windows_object_A2160():
    bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_window_object
    bpy.context.scene.sna_stored_window_object.select_set(state=True, )
    bpy.ops.object.duplicate_move_linked()
    bpy.context.active_object.name = 'Bool.Object.001'
    bpy.ops.object.modifier_remove('INVOKE_DEFAULT', modifier='Windows Object')
    bpy.context.scene.sna_stored_bool_object = None
    bpy.context.scene.sna_stored_bool_object = bpy.context.view_layer.objects.active
    if (property_exists("bpy.context.scene.collection.children", globals(), locals()) and 'BB.Window.Maker.Booleans' in bpy.context.scene.collection.children):
        pass
    else:
        collection_A92B3 = bpy.context.blend_data.collections.new(name='BB.Window.Maker.Booleans', )
        bpy.context.scene.collection.children.link(child=collection_A92B3, )
    bpy.ops.object.move_to_collection('INVOKE_DEFAULT', collection_index=int(bpy.context.scene.collection.children.find('BB.Window.Maker.Booleans') + 1.0))
    bpy.context.scene.sna_stored_bool_object.hide_render = True
    bpy.context.scene.sna_stored_bool_object.hide_viewport = True
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.scene.sna_stored_window_object.select_set(state=True, )
    bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[62].default_value = bpy.context.scene.sna_stored_bool_object


def sna_create_win_uv_E5805():
    if property_exists("bpy.context.object.data.uv_layer_stencil.id_data.uv_layers[0]", globals(), locals()):
        for i_5EA37 in range(len(bpy.context.object.data.uv_layer_stencil.id_data.uv_layers)):
            bpy.ops.mesh.uv_texture_remove('INVOKE_DEFAULT', )
    for i_1D71C in range(12):
        bpy.context.active_object.data.attributes.active = bpy.context.active_object.data.attributes[i_1D71C]
        if ((bpy.context.active_object.data.attributes.active.name if property_exists("bpy.context.active_object.data.attributes.active.name", globals(), locals()) else None) == level_07_extras['sna_stored_uv_attr']):
            break
    exec("bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')")


class SNA_OT_Transfer_Win_Settings_Ee8D2(bpy.types.Operator):
    bl_idname = "sna.transfer_win_settings_ee8d2"
    bl_label = "Transfer Win Settings"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.make_links_data(type='MODIFIERS')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clear_all_bool_objects_and_modiifers_13959():
    if bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value:
        print('picka')
        sna_clear_bool_object_function_5A0FF(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59].default_value)
        sna_clear_single_wall_bool_modifier_16E52(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59].default_value)
    else:
        print('picka')
        for i_F61F7 in range(len(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects)):
            sna_clear_bool_object_function_5A0FF(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects[i_F61F7])
            sna_clear_single_wall_bool_modifier_16E52(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects[i_F61F7])


def sna_function_apply_hole_single_A9AE7(Wall_object):
    bpy.context.view_layer.objects.active = Wall_object
    if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'BB.GeometryNodesBoolean' in bpy.context.active_object.modifiers):
        bpy.ops.object.modifier_apply('INVOKE_DEFAULT', modifier='BB.GeometryNodesBoolean')


class SNA_OT_Apply_Holes_Ef098(bpy.types.Operator):
    bl_idname = "sna.apply_holes_ef098"
    bl_label = "Apply Holes"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[4].default_value = False
        if bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value:
            print('picka')
            sna_function_apply_hole_single_A9AE7(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59].default_value)
        else:
            print('picka')
            for i_F0EB5 in range(len(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects)):
                sna_function_apply_hole_single_A9AE7(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects[i_F0EB5])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_Create_Holes_93634(bpy.types.Operator):
    bl_idname = "sna.operator_create_holes_93634"
    bl_label = "Operator Create Holes"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.sna_bool_boolean = True
        bpy.context.scene.sna_help_bool_counter = 0
        bpy.context.scene.sna_stored_window_object = None
        bpy.context.scene.sna_stored_bool_object = None
        bpy.context.scene.sna_stored_window_object = bpy.context.view_layer.objects.active
        bpy.ops.object.select_all(action='DESELECT')
        sna_clear_all_bool_objects_and_modiifers_13959()
        bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_window_object
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.sna_stored_window_object.select_set(state=True, )
        sna_create_bool_object_from_windows_object_A2160()
        if (property_exists("bpy.data.node_groups", globals(), locals()) and 'BB.Bools.Geonode' in bpy.data.node_groups):
            pass
        else:
            sna_function_create_bbboolsgeonode_02341()
        bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_window_object
        if bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value:
            sna_function_create_holes_2E568(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59].default_value)
            bpy.context.view_layer.objects.active = bpy.context.scene.sna_stored_window_object
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.sna_stored_window_object.select_set(state=True, )
        else:
            for i_2CAA9 in range(len(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects)):
                sna_function_create_holes_2E568(bpy.context.scene.sna_stored_window_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value.all_objects[i_2CAA9])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_Apply_Window_Geometry_3022E(bpy.types.Operator):
    bl_idname = "sna.operator_apply_window_geometry_3022e"
    bl_label = "Operator Apply Window Geometry"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        sna_function_duplicate_win_object_1C851()
        level_07_extras['sna_stored_uv_attr'] = ''
        if ('' == bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[28].default_value):
            level_07_extras['sna_stored_uv_attr'] = 'BB.UV.Map'
            bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[28].default_value = 'BB.UV.Map'
        else:
            level_07_extras['sna_stored_uv_attr'] = bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[28].default_value
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[63].default_value = True
        if bpy.context.view_layer.objects.active.type == 'MESH':
            bpy.ops.object.modifier_apply('INVOKE_DEFAULT', modifier='Windows Object')
        else:
            bpy.ops.object.convert('INVOKE_DEFAULT', target='MESH')
        sna_create_win_uv_E5805()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_function_duplicate_win_object_1C851():
    bpy.context.scene.sna_store_start_window_obj = None
    bpy.context.scene.sna_store_start_window_obj = bpy.context.view_layer.objects.active
    bpy.ops.object.duplicate_move()
    bpy.context.scene.sna_store_duplicated_window_obj = None
    bpy.context.scene.sna_store_duplicated_window_obj = bpy.context.view_layer.objects.active
    bpy.ops.object.select_all()
    bpy.context.view_layer.objects.active = None
    bpy.context.scene.sna_store_start_window_obj.select_set(state=True, )
    bpy.ops.object.delete()
    bpy.context.scene.sna_store_duplicated_window_obj.select_set(state=True, )
    bpy.context.view_layer.objects.active = bpy.context.scene.sna_store_duplicated_window_obj


class SNA_OT_Add_Window_Dfe99(bpy.types.Operator):
    bl_idname = "sna.add_window_dfe99"
    bl_label = "Add Window"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if True:
            if (property_exists("bpy.data.node_groups", globals(), locals()) and 'BB.Windows.Geonode' in bpy.data.node_groups):
                pass
            else:
                before_data = list(bpy.data.node_groups)
                bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'TotalWindows.4.0.blend') + r'\NodeTree', filename='BB.Windows.Geonode', link=False)
                new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
                appended_BCB61 = None if not new_data else new_data[0]
            if (property_exists("bpy.data.node_groups", globals(), locals()) and 'BB.Windows' in bpy.data.node_groups):
                pass
            else:
                before_data = list(bpy.data.node_groups)
                bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'TotalWindows.4.0.blend') + r'\NodeTree', filename='BB.Windows', link=True)
                new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
                appended_ED4D0 = None if not new_data else new_data[0]
            bpy.context.view_layer.objects.active.select_set(state=True, )
            bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='NODES')
            bpy.context.active_object.modifiers.active.name = 'Windows Object'
            bpy.context.active_object.modifiers.active.node_group = bpy.data.node_groups[bpy.data.node_groups.find('BB.Windows.Geonode')]
            bpy.data.node_groups['BB.Windows.Geonode'].nodes['Group'].node_tree = bpy.data.node_groups[bpy.data.node_groups.find('BB.Windows')]
            link_5F727 = bpy.data.node_groups['BB.Windows.Geonode'].links.new(input=bpy.data.node_groups['BB.Windows.Geonode'].nodes['Group'].outputs[0], output=bpy.data.node_groups['BB.Windows.Geonode'].nodes['Group Output'].inputs[0], )
            bpy.ops.object.geometry_node_tree_copy_assign('INVOKE_DEFAULT', )
            bpy.data.node_groups.remove(tree=bpy.data.node_groups[bpy.data.node_groups.find('BB.Windows.Geonode')], )
            bpy.data.node_groups.remove(tree=bpy.data.node_groups[bpy.data.node_groups.find('BB.help.windows')], )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Single_Window_70536(bpy.types.Operator):
    bl_idname = "sna.single_window_70536"
    bl_label = "Single Window"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value = 1
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[1].default_value = 0.07999999821186066
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[31].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Handle_D61Ee(bpy.types.Operator):
    bl_idname = "sna.show_handle_d61ee"
    bl_label = "Show handle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Handle_6F919(bpy.types.Operator):
    bl_idname = "sna.hide_handle_6f919"
    bl_label = "Hide handle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Multiple_Vindows_2A7Ad(bpy.types.Operator):
    bl_idname = "sna.multiple_vindows_2a7ad"
    bl_label = "Multiple Vindows"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value = 0
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[1].default_value = 0.07999999821186066
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Only_Frames_A2577(bpy.types.Operator):
    bl_idname = "sna.only_frames_a2577"
    bl_label = "Only Frames"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value = 2
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[1].default_value = 0.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Custom_Handle_C2C60(bpy.types.Operator):
    bl_idname = "sna.custom_handle_c2c60"
    bl_label = "Custom Handle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[17].default_value = (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[17].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Sill_A56F4(bpy.types.Operator):
    bl_idname = "sna.show_sill_a56f4"
    bl_label = "Show sill"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value = 1
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Sill_Ef647(bpy.types.Operator):
    bl_idname = "sna.hide_sill_ef647"
    bl_label = "Hide Sill"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value = 0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Blinds_Random_C6Bb8(bpy.types.Operator):
    bl_idname = "sna.blinds_random_c6bb8"
    bl_label = "Blinds Random"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Blinds_Box_4Facc(bpy.types.Operator):
    bl_idname = "sna.show_blinds_box_4facc"
    bl_label = "Show Blinds Box"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Blinds_Box_Ec951(bpy.types.Operator):
    bl_idname = "sna.hide_blinds_box_ec951"
    bl_label = "Hide Blinds Box"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Blinds_Same_F3622(bpy.types.Operator):
    bl_idname = "sna.blinds_same_f3622"
    bl_label = "Blinds Same"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Hindge_23F0F(bpy.types.Operator):
    bl_idname = "sna.show_hindge_23f0f"
    bl_label = "Show Hindge"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Hindge_133F5(bpy.types.Operator):
    bl_idname = "sna.hide_hindge_133f5"
    bl_label = "Hide Hindge"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Custom_Hindge_02E65(bpy.types.Operator):
    bl_idname = "sna.custom_hindge_02e65"
    bl_label = "Custom Hindge"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[50].default_value = (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[50].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Object_Or_Collection_E2Fa7(bpy.types.Operator):
    bl_idname = "sna.object_or_collection_e2fa7"
    bl_label = "Object or Collection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers.active.node_group.nodes['Group'].inputs[58].default_value = (not bpy.context.active_object.modifiers.active.node_group.nodes['Group'].inputs[58].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Glass_Fbe21(bpy.types.Operator):
    bl_idname = "sna.show_glass_fbe21"
    bl_label = "Show glass"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Glass_Ba90E(bpy.types.Operator):
    bl_idname = "sna.hide_glass_ba90e"
    bl_label = "Hide glass"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Top_Hung_Mode_75546(bpy.types.Operator):
    bl_idname = "sna.top_hung_mode_75546"
    bl_label = "Top Hung Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value = True
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13].default_value = 0.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Turn_Mode_Dd665(bpy.types.Operator):
    bl_idname = "sna.turn_mode_dd665"
    bl_label = "Turn Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value = False
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13].default_value = 1.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Blinds_E685B(bpy.types.Operator):
    bl_idname = "sna.show_blinds_e685b"
    bl_label = "Show Blinds"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value = True
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Blinds_D0Bf2(bpy.types.Operator):
    bl_idname = "sna.hide_blinds_d0bf2"
    bl_label = "Hide Blinds"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value = False
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Same_Angle_Bd955(bpy.types.Operator):
    bl_idname = "sna.same_angle_bd955"
    bl_label = "Same Angle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Random_Angle_68279(bpy.types.Operator):
    bl_idname = "sna.random_angle_68279"
    bl_label = "Random Angle"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Booleans_C39Bf(bpy.types.Operator):
    bl_idname = "sna.show_booleans_c39bf"
    bl_label = "Show Booleans"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[4].default_value = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Hide_Booleans_B4F87(bpy.types.Operator):
    bl_idname = "sna.hide_booleans_b4f87"
    bl_label = "Hide Booleans"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[4].default_value = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Flip_Left_Right_70C9F(bpy.types.Operator):
    bl_idname = "sna.flip_left_right_70c9f"
    bl_label = "Flip Left Right"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[54].default_value = (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[54].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Adjust_Corner_3Ea64(bpy.types.Operator):
    bl_idname = "sna.adjust_corner_3ea64"
    bl_label = "Adjust corner"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[31].default_value = (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[31].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Flip_Inside_Out_2Bc8C(bpy.types.Operator):
    bl_idname = "sna.flip_inside_out_2bc8c"
    bl_label = "Flip inside out"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[61].default_value = (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[61].default_value)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class WINDOW_PT(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'WINDOW_PT'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'RENDER_PT_Window'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.label(text='Windows', icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'window_icon.png')))

    def draw(self, context):
        layout = self.layout
        if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers):
            pass
        else:
            op = layout.operator('sna.add_window_dfe99', text='Create Windows', icon_value=0, emboss=True, depress=False)


class SNA_PT_WINDOW_MODE_55E55(bpy.types.Panel):
    bl_label = 'Window Mode'
    bl_idname = 'SNA_PT_WINDOW_MODE_55E55'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        split_6BF38 = layout.split(factor=0.33000001311302185, align=False)
        split_6BF38.alert = False
        split_6BF38.enabled = True
        split_6BF38.active = True
        split_6BF38.use_property_split = False
        split_6BF38.use_property_decorate = False
        split_6BF38.scale_x = 1.0
        split_6BF38.scale_y = 1.0
        split_6BF38.alignment = 'Center'.upper()
        if not True: split_6BF38.operator_context = "EXEC_DEFAULT"
        op = split_6BF38.operator('sna.single_window_70536', text='Double Wing', icon_value=0, emboss=True, depress=(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 1))
        split_3C69B = split_6BF38.split(factor=0.5, align=False)
        split_3C69B.alert = False
        split_3C69B.enabled = True
        split_3C69B.active = True
        split_3C69B.use_property_split = False
        split_3C69B.use_property_decorate = False
        split_3C69B.scale_x = 1.0
        split_3C69B.scale_y = 1.0
        split_3C69B.alignment = 'Expand'.upper()
        if not True: split_3C69B.operator_context = "EXEC_DEFAULT"
        op = split_3C69B.operator('sna.multiple_vindows_2a7ad', text='Multiple', icon_value=0, emboss=True, depress=(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 0))
        op = split_3C69B.operator('sna.only_frames_a2577', text='Fixed', icon_value=0, emboss=True, depress=(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2))


class SNA_PT_FRAME_389A6(bpy.types.Panel):
    bl_label = 'Frame'
    bl_idname = 'SNA_PT_FRAME_389A6'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_8C944 = layout.column(heading='', align=False)
        col_8C944.alert = False
        col_8C944.enabled = True
        col_8C944.active = True
        col_8C944.use_property_split = False
        col_8C944.use_property_decorate = False
        col_8C944.scale_x = 1.0
        col_8C944.scale_y = 1.0
        col_8C944.alignment = 'Center'.upper()
        col_8C944.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_24FD2 = col_8C944.split(factor=0.6000000238418579, align=False)
        split_24FD2.alert = False
        split_24FD2.enabled = True
        split_24FD2.active = True
        split_24FD2.use_property_split = False
        split_24FD2.use_property_decorate = False
        split_24FD2.scale_x = 1.0
        split_24FD2.scale_y = 1.0
        split_24FD2.alignment = 'Center'.upper()
        if not True: split_24FD2.operator_context = "EXEC_DEFAULT"
        row_ECD1F = split_24FD2.row(heading='', align=False)
        row_ECD1F.alert = False
        row_ECD1F.enabled = True
        row_ECD1F.active = True
        row_ECD1F.use_property_split = False
        row_ECD1F.use_property_decorate = False
        row_ECD1F.scale_x = 1.0
        row_ECD1F.scale_y = 0.0
        row_ECD1F.alignment = 'Right'.upper()
        row_ECD1F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_ECD1F.label(text='Frame Depth', icon_value=0)
        split_24FD2.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[3], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2):
            pass
        else:
            split_A8DEF = col_8C944.split(factor=0.6000000238418579, align=False)
            split_A8DEF.alert = False
            split_A8DEF.enabled = True
            split_A8DEF.active = True
            split_A8DEF.use_property_split = False
            split_A8DEF.use_property_decorate = False
            split_A8DEF.scale_x = 1.0
            split_A8DEF.scale_y = 1.0
            split_A8DEF.alignment = 'Center'.upper()
            if not True: split_A8DEF.operator_context = "EXEC_DEFAULT"
            row_689C2 = split_A8DEF.row(heading='', align=False)
            row_689C2.alert = False
            row_689C2.enabled = True
            row_689C2.active = True
            row_689C2.use_property_split = False
            row_689C2.use_property_decorate = False
            row_689C2.scale_x = 1.0
            row_689C2.scale_y = 0.0
            row_689C2.alignment = 'Right'.upper()
            row_689C2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_689C2.label(text='Outer Frame Thickness', icon_value=0)
            split_A8DEF.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[1], 'default_value', text='', icon_value=0, emboss=True)
        split_4B40B = col_8C944.split(factor=0.6000000238418579, align=False)
        split_4B40B.alert = False
        split_4B40B.enabled = True
        split_4B40B.active = True
        split_4B40B.use_property_split = False
        split_4B40B.use_property_decorate = False
        split_4B40B.scale_x = 1.0
        split_4B40B.scale_y = 1.0
        split_4B40B.alignment = 'Center'.upper()
        if not True: split_4B40B.operator_context = "EXEC_DEFAULT"
        row_648D9 = split_4B40B.row(heading='', align=False)
        row_648D9.alert = False
        row_648D9.enabled = True
        row_648D9.active = True
        row_648D9.use_property_split = False
        row_648D9.use_property_decorate = False
        row_648D9.scale_x = 1.0
        row_648D9.scale_y = 0.0
        row_648D9.alignment = 'Right'.upper()
        row_648D9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2):
            row_648D9.label(text='Frame Thickness', icon_value=0)
        else:
            row_648D9.label(text='Inner Frame Thickness', icon_value=0)
        split_4B40B.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[2], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2):
            pass
        else:
            split_1721C = col_8C944.split(factor=0.6000000238418579, align=False)
            split_1721C.alert = False
            split_1721C.enabled = True
            split_1721C.active = True
            split_1721C.use_property_split = False
            split_1721C.use_property_decorate = False
            split_1721C.scale_x = 1.0
            split_1721C.scale_y = 1.0
            split_1721C.alignment = 'Center'.upper()
            if not True: split_1721C.operator_context = "EXEC_DEFAULT"
            row_384BC = split_1721C.row(heading='', align=False)
            row_384BC.alert = False
            row_384BC.enabled = True
            row_384BC.active = True
            row_384BC.use_property_split = False
            row_384BC.use_property_decorate = False
            row_384BC.scale_x = 1.0
            row_384BC.scale_y = 0.0
            row_384BC.alignment = 'Right'.upper()
            row_384BC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_384BC.label(text='Frame Overlap', icon_value=0)
            split_1721C.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[4], 'default_value', text='', icon_value=0, emboss=True)
        split_8EC38 = col_8C944.split(factor=0.6000000238418579, align=False)
        split_8EC38.alert = False
        split_8EC38.enabled = True
        split_8EC38.active = True
        split_8EC38.use_property_split = False
        split_8EC38.use_property_decorate = False
        split_8EC38.scale_x = 1.0
        split_8EC38.scale_y = 1.0
        split_8EC38.alignment = 'Center'.upper()
        if not True: split_8EC38.operator_context = "EXEC_DEFAULT"
        row_783D5 = split_8EC38.row(heading='', align=False)
        row_783D5.alert = False
        row_783D5.enabled = True
        row_783D5.active = True
        row_783D5.use_property_split = False
        row_783D5.use_property_decorate = False
        row_783D5.scale_x = 1.0
        row_783D5.scale_y = 0.0
        row_783D5.alignment = 'Right'.upper()
        row_783D5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_783D5.label(text='Adjust Window Depth', icon_value=0)
        split_8EC38.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[32], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_GLASS_DA0EE(bpy.types.Panel):
    bl_label = 'Glass'
    bl_idname = 'SNA_PT_GLASS_DA0EE'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_7A31D = layout.column(heading='', align=False)
        col_7A31D.alert = False
        col_7A31D.enabled = True
        col_7A31D.active = True
        col_7A31D.use_property_split = False
        col_7A31D.use_property_decorate = False
        col_7A31D.scale_x = 1.0
        col_7A31D.scale_y = 1.0
        col_7A31D.alignment = 'Center'.upper()
        col_7A31D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_F391E = col_7A31D.row(heading='', align=False)
        row_F391E.alert = False
        row_F391E.enabled = True
        row_F391E.active = True
        row_F391E.use_property_split = False
        row_F391E.use_property_decorate = False
        row_F391E.scale_x = 1.0
        row_F391E.scale_y = 1.0
        row_F391E.alignment = 'Expand'.upper()
        row_F391E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_33555 = row_F391E.split(factor=0.5, align=False)
        split_33555.alert = False
        split_33555.enabled = True
        split_33555.active = True
        split_33555.use_property_split = False
        split_33555.use_property_decorate = False
        split_33555.scale_x = 1.0
        split_33555.scale_y = 1.0
        split_33555.alignment = 'Expand'.upper()
        if not True: split_33555.operator_context = "EXEC_DEFAULT"
        op = split_33555.operator('sna.show_glass_fbe21', text='Show', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value)
        op = split_33555.operator('sna.hide_glass_ba90e', text='Hide', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value:
            split_A1AE1 = col_7A31D.split(factor=0.6000000238418579, align=False)
            split_A1AE1.alert = False
            split_A1AE1.enabled = True
            split_A1AE1.active = True
            split_A1AE1.use_property_split = False
            split_A1AE1.use_property_decorate = False
            split_A1AE1.scale_x = 1.0
            split_A1AE1.scale_y = 1.0
            split_A1AE1.alignment = 'Center'.upper()
            if not True: split_A1AE1.operator_context = "EXEC_DEFAULT"
            row_79EF6 = split_A1AE1.row(heading='', align=False)
            row_79EF6.alert = False
            row_79EF6.enabled = True
            row_79EF6.active = True
            row_79EF6.use_property_split = False
            row_79EF6.use_property_decorate = False
            row_79EF6.scale_x = 1.0
            row_79EF6.scale_y = 0.0
            row_79EF6.alignment = 'Right'.upper()
            row_79EF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_79EF6.label(text='Thickness', icon_value=0)
            split_A1AE1.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[9], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_OPENING_A5C10(bpy.types.Panel):
    bl_label = 'Opening'
    bl_idname = 'SNA_PT_OPENING_A5C10'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)) or (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_D1194 = layout.column(heading='', align=False)
        col_D1194.alert = False
        col_D1194.enabled = True
        col_D1194.active = True
        col_D1194.use_property_split = False
        col_D1194.use_property_decorate = False
        col_D1194.scale_x = 1.0
        col_D1194.scale_y = 1.0
        col_D1194.alignment = 'Center'.upper()
        col_D1194.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            split_1A9F1 = col_D1194.split(factor=0.5, align=False)
            split_1A9F1.alert = False
            split_1A9F1.enabled = True
            split_1A9F1.active = True
            split_1A9F1.use_property_split = False
            split_1A9F1.use_property_decorate = False
            split_1A9F1.scale_x = 1.0
            split_1A9F1.scale_y = 1.0
            split_1A9F1.alignment = 'Expand'.upper()
            if not True: split_1A9F1.operator_context = "EXEC_DEFAULT"
            op = split_1A9F1.operator('sna.turn_mode_dd665', text='Turn Mode', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value))
            op = split_1A9F1.operator('sna.top_hung_mode_75546', text='Top Hung Mode', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value)
        if (not (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value)):
            split_8A79C = col_D1194.split(factor=0.5, align=False)
            split_8A79C.alert = False
            split_8A79C.enabled = True
            split_8A79C.active = True
            split_8A79C.use_property_split = False
            split_8A79C.use_property_decorate = False
            split_8A79C.scale_x = 1.0
            split_8A79C.scale_y = 1.0
            split_8A79C.alignment = 'Expand'.upper()
            if not True: split_8A79C.operator_context = "EXEC_DEFAULT"
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
                op = split_8A79C.operator('sna.same_angle_bd955', text='Different Angles', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value))
            else:
                op = split_8A79C.operator('sna.same_angle_bd955', text='Random Angle', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value))
            op = split_8A79C.operator('sna.random_angle_68279', text='Same Angle', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value)
        if (not (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[55].default_value)):
            split_542EA = col_D1194.split(factor=0.6000000238418579, align=False)
            split_542EA.alert = False
            split_542EA.enabled = True
            split_542EA.active = True
            split_542EA.use_property_split = False
            split_542EA.use_property_decorate = False
            split_542EA.scale_x = 1.0
            split_542EA.scale_y = 1.0
            split_542EA.alignment = 'Center'.upper()
            if not True: split_542EA.operator_context = "EXEC_DEFAULT"
            row_B55AB = split_542EA.row(heading='', align=False)
            row_B55AB.alert = False
            row_B55AB.enabled = True
            row_B55AB.active = True
            row_B55AB.use_property_split = False
            row_B55AB.use_property_decorate = False
            row_B55AB.scale_x = 1.0
            row_B55AB.scale_y = 0.0
            row_B55AB.alignment = 'Right'.upper()
            row_B55AB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
                row_B55AB.label(text='Angle', icon_value=0)
            else:
                if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value:
                    row_B55AB.label(text='Angle', icon_value=0)
                else:
                    row_B55AB.label(text='Maximum Angle', icon_value=0)
            split_542EA.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[5], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value:
                pass
            else:
                split_75BB9 = col_D1194.split(factor=0.6000000238418579, align=False)
                split_75BB9.alert = False
                split_75BB9.enabled = True
                split_75BB9.active = True
                split_75BB9.use_property_split = False
                split_75BB9.use_property_decorate = False
                split_75BB9.scale_x = 1.0
                split_75BB9.scale_y = 1.0
                split_75BB9.alignment = 'Center'.upper()
                if not True: split_75BB9.operator_context = "EXEC_DEFAULT"
                row_4977D = split_75BB9.row(heading='', align=False)
                row_4977D.alert = False
                row_4977D.enabled = True
                row_4977D.active = True
                row_4977D.use_property_split = False
                row_4977D.use_property_decorate = False
                row_4977D.scale_x = 1.0
                row_4977D.scale_y = 0.0
                row_4977D.alignment = 'Right'.upper()
                row_4977D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_4977D.label(text='Angle 2', icon_value=0)
                split_75BB9.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[53], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[10].default_value:
                pass
            else:
                split_CD6FD = col_D1194.split(factor=0.6000000238418579, align=False)
                split_CD6FD.alert = False
                split_CD6FD.enabled = True
                split_CD6FD.active = True
                split_CD6FD.use_property_split = False
                split_CD6FD.use_property_decorate = False
                split_CD6FD.scale_x = 1.0
                split_CD6FD.scale_y = 1.0
                split_CD6FD.alignment = 'Center'.upper()
                if not True: split_CD6FD.operator_context = "EXEC_DEFAULT"
                row_E54DB = split_CD6FD.row(heading='', align=False)
                row_E54DB.alert = False
                row_E54DB.enabled = True
                row_E54DB.active = True
                row_E54DB.use_property_split = False
                row_E54DB.use_property_decorate = False
                row_E54DB.scale_x = 1.0
                row_E54DB.scale_y = 0.0
                row_E54DB.alignment = 'Right'.upper()
                row_E54DB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_E54DB.label(text='Seed Angle', icon_value=0)
                split_CD6FD.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[6], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            split_45D8E = col_D1194.split(factor=0.6000000238418579, align=False)
            split_45D8E.alert = False
            split_45D8E.enabled = True
            split_45D8E.active = True
            split_45D8E.use_property_split = False
            split_45D8E.use_property_decorate = False
            split_45D8E.scale_x = 1.0
            split_45D8E.scale_y = 1.0
            split_45D8E.alignment = 'Center'.upper()
            if not True: split_45D8E.operator_context = "EXEC_DEFAULT"
            row_D1A81 = split_45D8E.row(heading='', align=False)
            row_D1A81.alert = False
            row_D1A81.enabled = True
            row_D1A81.active = True
            row_D1A81.use_property_split = False
            row_D1A81.use_property_decorate = False
            row_D1A81.scale_x = 1.0
            row_D1A81.scale_y = 0.0
            row_D1A81.alignment = 'Right'.upper()
            row_D1A81.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_D1A81.label(text='Probability Closed - Open', icon_value=0)
            split_45D8E.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[7], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            split_275C7 = col_D1194.split(factor=0.6000000238418579, align=False)
            split_275C7.alert = False
            split_275C7.enabled = True
            split_275C7.active = True
            split_275C7.use_property_split = False
            split_275C7.use_property_decorate = False
            split_275C7.scale_x = 1.0
            split_275C7.scale_y = 1.0
            split_275C7.alignment = 'Center'.upper()
            if not True: split_275C7.operator_context = "EXEC_DEFAULT"
            row_65460 = split_275C7.row(heading='', align=False)
            row_65460.alert = False
            row_65460.enabled = True
            row_65460.active = True
            row_65460.use_property_split = False
            row_65460.use_property_decorate = False
            row_65460.scale_x = 1.0
            row_65460.scale_y = 0.0
            row_65460.alignment = 'Right'.upper()
            row_65460.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_65460.label(text='Seed', icon_value=0)
            split_275C7.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[8], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            if (0.0 != bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13].default_value):
                split_A46C2 = col_D1194.split(factor=0.6000000238418579, align=False)
                split_A46C2.alert = False
                split_A46C2.enabled = True
                split_A46C2.active = True
                split_A46C2.use_property_split = False
                split_A46C2.use_property_decorate = False
                split_A46C2.scale_x = 1.0
                split_A46C2.scale_y = 1.0
                split_A46C2.alignment = 'Center'.upper()
                if not True: split_A46C2.operator_context = "EXEC_DEFAULT"
                row_76A9E = split_A46C2.row(heading='', align=False)
                row_76A9E.alert = False
                row_76A9E.enabled = True
                row_76A9E.active = True
                row_76A9E.use_property_split = False
                row_76A9E.use_property_decorate = False
                row_76A9E.scale_x = 1.0
                row_76A9E.scale_y = 0.0
                row_76A9E.alignment = 'Right'.upper()
                row_76A9E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_76A9E.label(text='Probability Left - Right', icon_value=0)
                split_A46C2.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[11], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            if (0.0 != bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13].default_value):
                split_4FE30 = col_D1194.split(factor=0.6000000238418579, align=False)
                split_4FE30.alert = False
                split_4FE30.enabled = True
                split_4FE30.active = True
                split_4FE30.use_property_split = False
                split_4FE30.use_property_decorate = False
                split_4FE30.scale_x = 1.0
                split_4FE30.scale_y = 1.0
                split_4FE30.alignment = 'Center'.upper()
                if not True: split_4FE30.operator_context = "EXEC_DEFAULT"
                row_39A3B = split_4FE30.row(heading='', align=False)
                row_39A3B.alert = False
                row_39A3B.enabled = True
                row_39A3B.active = True
                row_39A3B.use_property_split = False
                row_39A3B.use_property_decorate = False
                row_39A3B.scale_x = 1.0
                row_39A3B.scale_y = 0.0
                row_39A3B.alignment = 'Right'.upper()
                row_39A3B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_39A3B.label(text='Seed', icon_value=0)
                split_4FE30.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[12], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            if True:
                split_4CD14 = col_D1194.split(factor=0.6000000238418579, align=False)
                split_4CD14.alert = False
                split_4CD14.enabled = True
                split_4CD14.active = True
                split_4CD14.use_property_split = False
                split_4CD14.use_property_decorate = False
                split_4CD14.scale_x = 1.0
                split_4CD14.scale_y = 1.0
                split_4CD14.alignment = 'Center'.upper()
                if not True: split_4CD14.operator_context = "EXEC_DEFAULT"
                row_CB3F5 = split_4CD14.row(heading='', align=False)
                row_CB3F5.alert = False
                row_CB3F5.enabled = True
                row_CB3F5.active = True
                row_CB3F5.use_property_split = False
                row_CB3F5.use_property_decorate = False
                row_CB3F5.scale_x = 1.0
                row_CB3F5.scale_y = 0.0
                row_CB3F5.alignment = 'Right'.upper()
                row_CB3F5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_CB3F5.label(text='Probability Top Hung - Standard', icon_value=0)
                split_4CD14.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            pass
        else:
            if True:
                split_2B1AE = col_D1194.split(factor=0.6000000238418579, align=False)
                split_2B1AE.alert = False
                split_2B1AE.enabled = True
                split_2B1AE.active = True
                split_2B1AE.use_property_split = False
                split_2B1AE.use_property_decorate = False
                split_2B1AE.scale_x = 1.0
                split_2B1AE.scale_y = 1.0
                split_2B1AE.alignment = 'Center'.upper()
                if not True: split_2B1AE.operator_context = "EXEC_DEFAULT"
                row_92A64 = split_2B1AE.row(heading='', align=False)
                row_92A64.alert = False
                row_92A64.enabled = True
                row_92A64.active = True
                row_92A64.use_property_split = False
                row_92A64.use_property_decorate = False
                row_92A64.scale_x = 1.0
                row_92A64.scale_y = 0.0
                row_92A64.alignment = 'Right'.upper()
                row_92A64.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_92A64.label(text='Seed', icon_value=0)
                split_2B1AE.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[14], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[13].default_value != 1.0):
            split_04F22 = col_D1194.split(factor=0.6000000238418579, align=False)
            split_04F22.alert = False
            split_04F22.enabled = True
            split_04F22.active = True
            split_04F22.use_property_split = False
            split_04F22.use_property_decorate = False
            split_04F22.scale_x = 1.0
            split_04F22.scale_y = 1.0
            split_04F22.alignment = 'Center'.upper()
            if not True: split_04F22.operator_context = "EXEC_DEFAULT"
            row_C8328 = split_04F22.row(heading='', align=False)
            row_C8328.alert = False
            row_C8328.enabled = True
            row_C8328.active = True
            row_C8328.use_property_split = False
            row_C8328.use_property_decorate = False
            row_C8328.scale_x = 1.0
            row_C8328.scale_y = 0.0
            row_C8328.alignment = 'Right'.upper()
            row_C8328.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_C8328.label(text='Top Hung Opening Distance', icon_value=0)
            split_04F22.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[56], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value:
            op = col_D1194.operator('sna.flip_left_right_70c9f', text='Flip Left - Right', icon_value=0, emboss=True, depress=False)
        op = col_D1194.operator('sna.flip_inside_out_2bc8c', text='Flip Window Opening Inside Out', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[61].default_value)


class SNA_PT_HANDLE_32E97(bpy.types.Panel):
    bl_label = 'Handle'
    bl_idname = 'SNA_PT_HANDLE_32E97'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 5
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (((bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2) if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers) else True))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_29DE9 = layout.column(heading='General', align=False)
        col_29DE9.alert = False
        col_29DE9.enabled = True
        col_29DE9.active = True
        col_29DE9.use_property_split = False
        col_29DE9.use_property_decorate = False
        col_29DE9.scale_x = 1.0
        col_29DE9.scale_y = 1.0
        col_29DE9.alignment = 'Center'.upper()
        col_29DE9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_F74E8 = col_29DE9.split(factor=0.5, align=False)
        split_F74E8.alert = False
        split_F74E8.enabled = True
        split_F74E8.active = True
        split_F74E8.use_property_split = False
        split_F74E8.use_property_decorate = False
        split_F74E8.scale_x = 1.0
        split_F74E8.scale_y = 1.0
        split_F74E8.alignment = 'Expand'.upper()
        if not True: split_F74E8.operator_context = "EXEC_DEFAULT"
        op = split_F74E8.operator('sna.show_handle_d61ee', text='Show', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value)
        op = split_F74E8.operator('sna.hide_handle_6f919', text='Hide', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value:
            split_8036E = layout.split(factor=0.6000000238418579, align=False)
            split_8036E.alert = False
            split_8036E.enabled = True
            split_8036E.active = True
            split_8036E.use_property_split = False
            split_8036E.use_property_decorate = False
            split_8036E.scale_x = 1.0
            split_8036E.scale_y = 1.0
            split_8036E.alignment = 'Center'.upper()
            if not True: split_8036E.operator_context = "EXEC_DEFAULT"
            row_266C0 = split_8036E.row(heading='', align=False)
            row_266C0.alert = False
            row_266C0.enabled = True
            row_266C0.active = True
            row_266C0.use_property_split = False
            row_266C0.use_property_decorate = False
            row_266C0.scale_x = 1.0
            row_266C0.scale_y = 0.0
            row_266C0.alignment = 'Right'.upper()
            row_266C0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_266C0.label(text='Adjust Handle Height', icon_value=0)
            split_8036E.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[16], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value:
            op = layout.operator('sna.custom_handle_c2c60', text='Custom Handle Object', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[17].default_value)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[17].default_value:
                split_6E8EB = layout.split(factor=0.30000001192092896, align=False)
                split_6E8EB.alert = False
                split_6E8EB.enabled = True
                split_6E8EB.active = True
                split_6E8EB.use_property_split = False
                split_6E8EB.use_property_decorate = False
                split_6E8EB.scale_x = 1.0
                split_6E8EB.scale_y = 1.0
                split_6E8EB.alignment = 'Center'.upper()
                if not True: split_6E8EB.operator_context = "EXEC_DEFAULT"
                split_6E8EB.label(text='Base Object', icon_value=0)
                split_6E8EB.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[18], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[17].default_value:
                split_C2FA7 = layout.split(factor=0.30000001192092896, align=False)
                split_C2FA7.alert = False
                split_C2FA7.enabled = True
                split_C2FA7.active = True
                split_C2FA7.use_property_split = False
                split_C2FA7.use_property_decorate = False
                split_C2FA7.scale_x = 1.0
                split_C2FA7.scale_y = 1.0
                split_C2FA7.alignment = 'Center'.upper()
                if not True: split_C2FA7.operator_context = "EXEC_DEFAULT"
                split_C2FA7.label(text='Knob Object', icon_value=0)
                split_C2FA7.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[19], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_SILL_FD474(bpy.types.Panel):
    bl_label = 'Sill'
    bl_idname = 'SNA_PT_SILL_FD474'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 6
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_08557 = layout.column(heading='General', align=False)
        col_08557.alert = False
        col_08557.enabled = True
        col_08557.active = True
        col_08557.use_property_split = False
        col_08557.use_property_decorate = False
        col_08557.scale_x = 1.0
        col_08557.scale_y = 1.0
        col_08557.alignment = 'Center'.upper()
        col_08557.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        split_83A11 = col_08557.split(factor=0.5, align=False)
        split_83A11.alert = False
        split_83A11.enabled = True
        split_83A11.active = True
        split_83A11.use_property_split = False
        split_83A11.use_property_decorate = False
        split_83A11.scale_x = 1.0
        split_83A11.scale_y = 1.0
        split_83A11.alignment = 'Expand'.upper()
        if not True: split_83A11.operator_context = "EXEC_DEFAULT"
        op = split_83A11.operator('sna.show_sill_a56f4', text='Show', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value)
        op = split_83A11.operator('sna.hide_sill_ef647', text='Hide', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value:
            split_86293 = layout.split(factor=0.6000000238418579, align=False)
            split_86293.alert = False
            split_86293.enabled = True
            split_86293.active = True
            split_86293.use_property_split = False
            split_86293.use_property_decorate = False
            split_86293.scale_x = 1.0
            split_86293.scale_y = 1.0
            split_86293.alignment = 'Center'.upper()
            if not True: split_86293.operator_context = "EXEC_DEFAULT"
            row_9A32C = split_86293.row(heading='', align=False)
            row_9A32C.alert = False
            row_9A32C.enabled = True
            row_9A32C.active = True
            row_9A32C.use_property_split = False
            row_9A32C.use_property_decorate = False
            row_9A32C.scale_x = 1.0
            row_9A32C.scale_y = 0.0
            row_9A32C.alignment = 'Right'.upper()
            row_9A32C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_9A32C.label(text='Sill  Thickness', icon_value=0)
            split_86293.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[34], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value:
            split_76F8C = layout.split(factor=0.6000000238418579, align=False)
            split_76F8C.alert = False
            split_76F8C.enabled = True
            split_76F8C.active = True
            split_76F8C.use_property_split = False
            split_76F8C.use_property_decorate = False
            split_76F8C.scale_x = 1.0
            split_76F8C.scale_y = 1.0
            split_76F8C.alignment = 'Center'.upper()
            if not True: split_76F8C.operator_context = "EXEC_DEFAULT"
            row_7DF81 = split_76F8C.row(heading='', align=False)
            row_7DF81.alert = False
            row_7DF81.enabled = True
            row_7DF81.active = True
            row_7DF81.use_property_split = False
            row_7DF81.use_property_decorate = False
            row_7DF81.scale_x = 1.0
            row_7DF81.scale_y = 0.0
            row_7DF81.alignment = 'Right'.upper()
            row_7DF81.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_7DF81.label(text='Sill  Side Overlap', icon_value=0)
            split_76F8C.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[35], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value:
            split_65ADD = layout.split(factor=0.6000000238418579, align=False)
            split_65ADD.alert = False
            split_65ADD.enabled = True
            split_65ADD.active = True
            split_65ADD.use_property_split = False
            split_65ADD.use_property_decorate = False
            split_65ADD.scale_x = 1.0
            split_65ADD.scale_y = 1.0
            split_65ADD.alignment = 'Center'.upper()
            if not True: split_65ADD.operator_context = "EXEC_DEFAULT"
            row_2D08E = split_65ADD.row(heading='', align=False)
            row_2D08E.alert = False
            row_2D08E.enabled = True
            row_2D08E.active = True
            row_2D08E.use_property_split = False
            row_2D08E.use_property_decorate = False
            row_2D08E.scale_x = 1.0
            row_2D08E.scale_y = 0.0
            row_2D08E.alignment = 'Right'.upper()
            row_2D08E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_2D08E.label(text='Inner Depth Sill', icon_value=0)
            split_65ADD.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[36], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value:
            split_0875F = layout.split(factor=0.6000000238418579, align=False)
            split_0875F.alert = False
            split_0875F.enabled = True
            split_0875F.active = True
            split_0875F.use_property_split = False
            split_0875F.use_property_decorate = False
            split_0875F.scale_x = 1.0
            split_0875F.scale_y = 1.0
            split_0875F.alignment = 'Center'.upper()
            if not True: split_0875F.operator_context = "EXEC_DEFAULT"
            row_3F424 = split_0875F.row(heading='', align=False)
            row_3F424.alert = False
            row_3F424.enabled = True
            row_3F424.active = True
            row_3F424.use_property_split = False
            row_3F424.use_property_decorate = False
            row_3F424.scale_x = 1.0
            row_3F424.scale_y = 0.0
            row_3F424.alignment = 'Right'.upper()
            row_3F424.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3F424.label(text='Outer Depth Sill', icon_value=0)
            split_0875F.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[37], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_BLINDS_A0B05(bpy.types.Panel):
    bl_label = 'Blinds'
    bl_idname = 'SNA_PT_BLINDS_A0B05'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 7
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        split_A243E = layout.split(factor=0.5, align=False)
        split_A243E.alert = False
        split_A243E.enabled = True
        split_A243E.active = True
        split_A243E.use_property_split = False
        split_A243E.use_property_decorate = False
        split_A243E.scale_x = 1.0
        split_A243E.scale_y = 1.0
        split_A243E.alignment = 'Expand'.upper()
        if not True: split_A243E.operator_context = "EXEC_DEFAULT"
        op = split_A243E.operator('sna.show_blinds_e685b', text='Show Blinds', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value)
        op = split_A243E.operator('sna.hide_blinds_d0bf2', text='Hide Blinds', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
            if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value != 1):
                split_4209F = layout.split(factor=0.5, align=False)
                split_4209F.alert = False
                split_4209F.enabled = True
                split_4209F.active = True
                split_4209F.use_property_split = False
                split_4209F.use_property_decorate = False
                split_4209F.scale_x = 1.0
                split_4209F.scale_y = 1.0
                split_4209F.alignment = 'Expand'.upper()
                if not True: split_4209F.operator_context = "EXEC_DEFAULT"
                op = split_4209F.operator('sna.blinds_same_f3622', text='Same Size', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value))
                op = split_4209F.operator('sna.blinds_random_c6bb8', text='Random Size', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
            split_E62DE = layout.split(factor=0.6000000238418579, align=False)
            split_E62DE.alert = False
            split_E62DE.enabled = True
            split_E62DE.active = True
            split_E62DE.use_property_split = False
            split_E62DE.use_property_decorate = False
            split_E62DE.scale_x = 1.0
            split_E62DE.scale_y = 1.0
            split_E62DE.alignment = 'Center'.upper()
            if not True: split_E62DE.operator_context = "EXEC_DEFAULT"
            row_4BF8B = split_E62DE.row(heading='', align=False)
            row_4BF8B.alert = False
            row_4BF8B.enabled = True
            row_4BF8B.active = True
            row_4BF8B.use_property_split = False
            row_4BF8B.use_property_decorate = False
            row_4BF8B.scale_x = 1.0
            row_4BF8B.scale_y = 0.0
            row_4BF8B.alignment = 'Right'.upper()
            row_4BF8B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value != 1):
                if (not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value):
                    row_4BF8B.label(text='Size Blinds', icon_value=0)
                else:
                    row_4BF8B.label(text='Maximum Size Blinds', icon_value=0)
            else:
                row_4BF8B.label(text='Size Blinds', icon_value=0)
            split_E62DE.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[44], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
            split_8289C = layout.split(factor=0.6000000238418579, align=False)
            split_8289C.alert = False
            split_8289C.enabled = True
            split_8289C.active = True
            split_8289C.use_property_split = False
            split_8289C.use_property_decorate = False
            split_8289C.scale_x = 1.0
            split_8289C.scale_y = 1.0
            split_8289C.alignment = 'Center'.upper()
            if not True: split_8289C.operator_context = "EXEC_DEFAULT"
            row_48C71 = split_8289C.row(heading='', align=False)
            row_48C71.alert = False
            row_48C71.enabled = True
            row_48C71.active = True
            row_48C71.use_property_split = False
            row_48C71.use_property_decorate = False
            row_48C71.scale_x = 1.0
            row_48C71.scale_y = 0.0
            row_48C71.alignment = 'Right'.upper()
            row_48C71.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_48C71.label(text='Adjust Blinds Position', icon_value=0)
            split_8289C.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[45], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[46].default_value:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
                split_FDD02 = layout.split(factor=0.6000000238418579, align=False)
                split_FDD02.alert = False
                split_FDD02.enabled = True
                split_FDD02.active = True
                split_FDD02.use_property_split = False
                split_FDD02.use_property_decorate = False
                split_FDD02.scale_x = 1.0
                split_FDD02.scale_y = 1.0
                split_FDD02.alignment = 'Center'.upper()
                if not True: split_FDD02.operator_context = "EXEC_DEFAULT"
                row_001F7 = split_FDD02.row(heading='', align=False)
                row_001F7.alert = False
                row_001F7.enabled = True
                row_001F7.active = True
                row_001F7.use_property_split = False
                row_001F7.use_property_decorate = False
                row_001F7.scale_x = 1.0
                row_001F7.scale_y = 0.0
                row_001F7.alignment = 'Right'.upper()
                row_001F7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_001F7.label(text='Random Seed', icon_value=0)
                split_FDD02.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[47], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
            split_751E3 = layout.split(factor=0.5, align=False)
            split_751E3.alert = False
            split_751E3.enabled = True
            split_751E3.active = True
            split_751E3.use_property_split = False
            split_751E3.use_property_decorate = False
            split_751E3.scale_x = 1.0
            split_751E3.scale_y = 1.0
            split_751E3.alignment = 'Expand'.upper()
            if not True: split_751E3.operator_context = "EXEC_DEFAULT"
            op = split_751E3.operator('sna.show_blinds_box_4facc', text='Show Blinds Box', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value)
            op = split_751E3.operator('sna.hide_blinds_box_ec951', text='Hide Blinds Box', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value))
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value):
            split_5F9F3 = layout.split(factor=0.6000000238418579, align=False)
            split_5F9F3.alert = False
            split_5F9F3.enabled = True
            split_5F9F3.active = True
            split_5F9F3.use_property_split = False
            split_5F9F3.use_property_decorate = False
            split_5F9F3.scale_x = 1.0
            split_5F9F3.scale_y = 1.0
            split_5F9F3.alignment = 'Center'.upper()
            if not True: split_5F9F3.operator_context = "EXEC_DEFAULT"
            row_27F5F = split_5F9F3.row(heading='', align=False)
            row_27F5F.alert = False
            row_27F5F.enabled = True
            row_27F5F.active = True
            row_27F5F.use_property_split = False
            row_27F5F.use_property_decorate = False
            row_27F5F.scale_x = 1.0
            row_27F5F.scale_y = 0.0
            row_27F5F.alignment = 'Right'.upper()
            row_27F5F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_27F5F.label(text='Blinds Box Side Overlap', icon_value=0)
            split_5F9F3.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[39], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value):
            split_41669 = layout.split(factor=0.6000000238418579, align=False)
            split_41669.alert = False
            split_41669.enabled = True
            split_41669.active = True
            split_41669.use_property_split = False
            split_41669.use_property_decorate = False
            split_41669.scale_x = 1.0
            split_41669.scale_y = 1.0
            split_41669.alignment = 'Center'.upper()
            if not True: split_41669.operator_context = "EXEC_DEFAULT"
            row_BE44E = split_41669.row(heading='', align=False)
            row_BE44E.alert = False
            row_BE44E.enabled = True
            row_BE44E.active = True
            row_BE44E.use_property_split = False
            row_BE44E.use_property_decorate = False
            row_BE44E.scale_x = 1.0
            row_BE44E.scale_y = 0.0
            row_BE44E.alignment = 'Right'.upper()
            row_BE44E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_BE44E.label(text='Blinds Box Height', icon_value=0)
            split_41669.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[40], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value):
            split_0D16A = layout.split(factor=0.6000000238418579, align=False)
            split_0D16A.alert = False
            split_0D16A.enabled = True
            split_0D16A.active = True
            split_0D16A.use_property_split = False
            split_0D16A.use_property_decorate = False
            split_0D16A.scale_x = 1.0
            split_0D16A.scale_y = 1.0
            split_0D16A.alignment = 'Center'.upper()
            if not True: split_0D16A.operator_context = "EXEC_DEFAULT"
            row_2DD7A = split_0D16A.row(heading='', align=False)
            row_2DD7A.alert = False
            row_2DD7A.enabled = True
            row_2DD7A.active = True
            row_2DD7A.use_property_split = False
            row_2DD7A.use_property_decorate = False
            row_2DD7A.scale_x = 1.0
            row_2DD7A.scale_y = 0.0
            row_2DD7A.alignment = 'Right'.upper()
            row_2DD7A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_2DD7A.label(text='Blinds Box Outer Depth', icon_value=0)
            split_0D16A.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[41], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value and bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value):
            split_463A5 = layout.split(factor=0.6000000238418579, align=False)
            split_463A5.alert = False
            split_463A5.enabled = True
            split_463A5.active = True
            split_463A5.use_property_split = False
            split_463A5.use_property_decorate = False
            split_463A5.scale_x = 1.0
            split_463A5.scale_y = 1.0
            split_463A5.alignment = 'Center'.upper()
            if not True: split_463A5.operator_context = "EXEC_DEFAULT"
            row_7CEEB = split_463A5.row(heading='', align=False)
            row_7CEEB.alert = False
            row_7CEEB.enabled = True
            row_7CEEB.active = True
            row_7CEEB.use_property_split = False
            row_7CEEB.use_property_decorate = False
            row_7CEEB.scale_x = 1.0
            row_7CEEB.scale_y = 0.0
            row_7CEEB.alignment = 'Right'.upper()
            row_7CEEB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_7CEEB.label(text='Blinds Box Inner Depth', icon_value=0)
            split_463A5.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[42], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_EXTRAS_735DE(bpy.types.Panel):
    bl_label = 'Extras'
    bl_idname = 'SNA_PT_EXTRAS_735DE'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 10
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.operator_apply_window_geometry_3022e', text='Apply Geometry', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.make_win_unique_operator_2bf2a', text='Make Unique', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.transfer_win_settings_ee8d2', text='Transfer Settings', icon_value=0, emboss=True, depress=False)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 1):
            pass
        else:
            op = layout.operator('sna.adjust_corner_3ea64', text='Adjustment Switch for Corner Windows', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[31].default_value)


class SNA_PT_WALL_HOLES_020A0(bpy.types.Panel):
    bl_label = 'Wall Holes'
    bl_idname = 'SNA_PT_WALL_HOLES_020A0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 9
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Create Hole In:', icon_value=0)
        split_5CBEF = layout.split(factor=0.5, align=False)
        split_5CBEF.alert = False
        split_5CBEF.enabled = True
        split_5CBEF.active = True
        split_5CBEF.use_property_split = False
        split_5CBEF.use_property_decorate = False
        split_5CBEF.scale_x = 1.0
        split_5CBEF.scale_y = 1.0
        split_5CBEF.alignment = 'Expand'.upper()
        if not True: split_5CBEF.operator_context = "EXEC_DEFAULT"
        op = split_5CBEF.operator('sna.object_or_collection_e2fa7', text='Object', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value)
        op = split_5CBEF.operator('sna.object_or_collection_e2fa7', text='Collection', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value:
            split_0494E = layout.split(factor=0.4000000059604645, align=False)
            split_0494E.alert = False
            split_0494E.enabled = True
            split_0494E.active = True
            split_0494E.use_property_split = False
            split_0494E.use_property_decorate = False
            split_0494E.scale_x = 1.0
            split_0494E.scale_y = 1.0
            split_0494E.alignment = 'Center'.upper()
            if not True: split_0494E.operator_context = "EXEC_DEFAULT"
            row_CB1D4 = split_0494E.row(heading='', align=False)
            row_CB1D4.alert = False
            row_CB1D4.enabled = True
            row_CB1D4.active = True
            row_CB1D4.use_property_split = False
            row_CB1D4.use_property_decorate = False
            row_CB1D4.scale_x = 1.0
            row_CB1D4.scale_y = 0.0
            row_CB1D4.alignment = 'Right'.upper()
            row_CB1D4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_CB1D4.label(text='Object', icon_value=0)
            split_0494E.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59], 'default_value', text='', icon_value=0, emboss=True)
        else:
            split_612F5 = layout.split(factor=0.4000000059604645, align=False)
            split_612F5.alert = False
            split_612F5.enabled = True
            split_612F5.active = True
            split_612F5.use_property_split = False
            split_612F5.use_property_decorate = False
            split_612F5.scale_x = 1.0
            split_612F5.scale_y = 1.0
            split_612F5.alignment = 'Center'.upper()
            if not True: split_612F5.operator_context = "EXEC_DEFAULT"
            row_30D99 = split_612F5.row(heading='', align=False)
            row_30D99.alert = False
            row_30D99.enabled = True
            row_30D99.active = True
            row_30D99.use_property_split = False
            row_30D99.use_property_decorate = False
            row_30D99.scale_x = 1.0
            row_30D99.scale_y = 0.0
            row_30D99.alignment = 'Right'.upper()
            row_30D99.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_30D99.label(text='Collection', icon_value=0)
            split_612F5.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60], 'default_value', text='', icon_value=0, emboss=True)
        if ((bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[59].default_value if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[58].default_value else bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[60].default_value) == None):
            pass
        else:
            op = layout.operator('sna.operator_create_holes_93634', text='Create Holes', icon_value=0, emboss=True, depress=False)
        if bpy.context.view_layer.objects.active.sna_bool_boolean:
            split_20432 = layout.split(factor=0.5, align=False)
            split_20432.alert = False
            split_20432.enabled = True
            split_20432.active = True
            split_20432.use_property_split = False
            split_20432.use_property_decorate = False
            split_20432.scale_x = 1.0
            split_20432.scale_y = 1.0
            split_20432.alignment = 'Expand'.upper()
            if not True: split_20432.operator_context = "EXEC_DEFAULT"
            op = split_20432.operator('sna.show_booleans_c39bf', text='Show Booleans', icon_value=0, emboss=True, depress=bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[4].default_value)
            op = split_20432.operator('sna.hide_booleans_b4f87', text='Hide Booleans', icon_value=0, emboss=True, depress=(not bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[4].default_value))
        if bpy.context.view_layer.objects.active.sna_bool_boolean:
            split_049F6 = layout.split(factor=0.4000000059604645, align=False)
            split_049F6.alert = False
            split_049F6.enabled = True
            split_049F6.active = True
            split_049F6.use_property_split = False
            split_049F6.use_property_decorate = False
            split_049F6.scale_x = 1.0
            split_049F6.scale_y = 1.0
            split_049F6.alignment = 'Center'.upper()
            if not True: split_049F6.operator_context = "EXEC_DEFAULT"
            row_E813C = split_049F6.row(heading='', align=False)
            row_E813C.alert = False
            row_E813C.enabled = True
            row_E813C.active = True
            row_E813C.use_property_split = False
            row_E813C.use_property_decorate = False
            row_E813C.scale_x = 1.0
            row_E813C.scale_y = 0.0
            row_E813C.alignment = 'Right'.upper()
            row_E813C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_E813C.label(text='Thickness', icon_value=0)
            split_049F6.prop(bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[2], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.view_layer.objects.active.sna_bool_boolean:
            split_67494 = layout.split(factor=0.4000000059604645, align=False)
            split_67494.alert = False
            split_67494.enabled = True
            split_67494.active = True
            split_67494.use_property_split = False
            split_67494.use_property_decorate = False
            split_67494.scale_x = 1.0
            split_67494.scale_y = 1.0
            split_67494.alignment = 'Center'.upper()
            if not True: split_67494.operator_context = "EXEC_DEFAULT"
            row_16CAA = split_67494.row(heading='', align=False)
            row_16CAA.alert = False
            row_16CAA.enabled = True
            row_16CAA.active = True
            row_16CAA.use_property_split = False
            row_16CAA.use_property_decorate = False
            row_16CAA.scale_x = 1.0
            row_16CAA.scale_y = 0.0
            row_16CAA.alignment = 'Right'.upper()
            row_16CAA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_16CAA.label(text='Offset', icon_value=0)
            split_67494.prop(bpy.context.scene.sna_stored_wall_object.modifiers['BB.GeometryNodesBoolean'].node_group.nodes['Group'].inputs[3], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.view_layer.objects.active.sna_bool_boolean:
            op = layout.operator('sna.apply_holes_ef098', text='Apply Holes into Geometry', icon_value=0, emboss=True, depress=False)


class SNA_PT_HINDGE_A5E0A(bpy.types.Panel):
    bl_label = 'Hindge'
    bl_idname = 'SNA_PT_HINDGE_A5E0A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 7
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (((bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2) if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers) else True))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        split_EC768 = layout.split(factor=0.5, align=False)
        split_EC768.alert = False
        split_EC768.enabled = True
        split_EC768.active = True
        split_EC768.use_property_split = False
        split_EC768.use_property_decorate = False
        split_EC768.scale_x = 1.0
        split_EC768.scale_y = 1.0
        split_EC768.alignment = 'Expand'.upper()
        if not True: split_EC768.operator_context = "EXEC_DEFAULT"
        op = split_EC768.operator('sna.show_hindge_23f0f', text='Show', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value)
        op = split_EC768.operator('sna.hide_hindge_133f5', text='Hide', icon_value=0, emboss=True, depress=(not bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value))
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value:
            split_7B20F = layout.split(factor=0.6000000238418579, align=False)
            split_7B20F.alert = False
            split_7B20F.enabled = True
            split_7B20F.active = True
            split_7B20F.use_property_split = False
            split_7B20F.use_property_decorate = False
            split_7B20F.scale_x = 1.0
            split_7B20F.scale_y = 1.0
            split_7B20F.alignment = 'Center'.upper()
            if not True: split_7B20F.operator_context = "EXEC_DEFAULT"
            row_D1CC3 = split_7B20F.row(heading='', align=False)
            row_D1CC3.alert = False
            row_D1CC3.enabled = True
            row_D1CC3.active = True
            row_D1CC3.use_property_split = False
            row_D1CC3.use_property_decorate = False
            row_D1CC3.scale_x = 1.0
            row_D1CC3.scale_y = 0.0
            row_D1CC3.alignment = 'Right'.upper()
            row_D1CC3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_D1CC3.label(text='Adjust Hindge Height', icon_value=0)
            split_7B20F.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[49], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value:
            op = layout.operator('sna.custom_hindge_02e65', text='Custom Hindge Object', icon_value=0, emboss=True, depress=bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[50].default_value)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[50].default_value:
                layout.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[51], 'default_value', text='', icon_value=0, emboss=True)


class SNA_PT_MATERIALS_A93C4(bpy.types.Panel):
    bl_label = 'Materials'
    bl_idname = 'SNA_PT_MATERIALS_A93C4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 8
    bl_options = {'DEFAULT_CLOSED'}
    bl_parent_id = 'WINDOW_PT'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Windows Object' in bpy.context.active_object.modifiers)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if True:
            split_1584E = layout.split(factor=0.4000000059604645, align=False)
            split_1584E.alert = False
            split_1584E.enabled = True
            split_1584E.active = True
            split_1584E.use_property_split = False
            split_1584E.use_property_decorate = False
            split_1584E.scale_x = 1.0
            split_1584E.scale_y = 1.0
            split_1584E.alignment = 'Center'.upper()
            if not True: split_1584E.operator_context = "EXEC_DEFAULT"
            row_DFAE2 = split_1584E.row(heading='', align=False)
            row_DFAE2.alert = False
            row_DFAE2.enabled = True
            row_DFAE2.active = True
            row_DFAE2.use_property_split = False
            row_DFAE2.use_property_decorate = False
            row_DFAE2.scale_x = 1.0
            row_DFAE2.scale_y = 0.0
            row_DFAE2.alignment = 'Right'.upper()
            row_DFAE2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_DFAE2.label(text='Outer Frame', icon_value=0)
            split_1584E.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[20], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value != 2):
            split_FE8BF = layout.split(factor=0.4000000059604645, align=False)
            split_FE8BF.alert = False
            split_FE8BF.enabled = True
            split_FE8BF.active = True
            split_FE8BF.use_property_split = False
            split_FE8BF.use_property_decorate = False
            split_FE8BF.scale_x = 1.0
            split_FE8BF.scale_y = 1.0
            split_FE8BF.alignment = 'Center'.upper()
            if not True: split_FE8BF.operator_context = "EXEC_DEFAULT"
            row_9F45A = split_FE8BF.row(heading='', align=False)
            row_9F45A.alert = False
            row_9F45A.enabled = True
            row_9F45A.active = True
            row_9F45A.use_property_split = False
            row_9F45A.use_property_decorate = False
            row_9F45A.scale_x = 1.0
            row_9F45A.scale_y = 0.0
            row_9F45A.alignment = 'Right'.upper()
            row_9F45A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_9F45A.label(text='Inner Frame', icon_value=0)
            split_FE8BF.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[21], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[57].default_value:
            split_A511B = layout.split(factor=0.4000000059604645, align=False)
            split_A511B.alert = False
            split_A511B.enabled = True
            split_A511B.active = True
            split_A511B.use_property_split = False
            split_A511B.use_property_decorate = False
            split_A511B.scale_x = 1.0
            split_A511B.scale_y = 1.0
            split_A511B.alignment = 'Center'.upper()
            if not True: split_A511B.operator_context = "EXEC_DEFAULT"
            row_A4C8D = split_A511B.row(heading='', align=False)
            row_A4C8D.alert = False
            row_A4C8D.enabled = True
            row_A4C8D.active = True
            row_A4C8D.use_property_split = False
            row_A4C8D.use_property_decorate = False
            row_A4C8D.scale_x = 1.0
            row_A4C8D.scale_y = 0.0
            row_A4C8D.alignment = 'Right'.upper()
            row_A4C8D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_A4C8D.label(text='Glass', icon_value=0)
            split_A511B.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[22], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[15].default_value:
            split_C0A9A = layout.split(factor=0.4000000059604645, align=False)
            split_C0A9A.alert = False
            split_C0A9A.enabled = True
            split_C0A9A.active = True
            split_C0A9A.use_property_split = False
            split_C0A9A.use_property_decorate = False
            split_C0A9A.scale_x = 1.0
            split_C0A9A.scale_y = 1.0
            split_C0A9A.alignment = 'Center'.upper()
            if not True: split_C0A9A.operator_context = "EXEC_DEFAULT"
            row_46C02 = split_C0A9A.row(heading='', align=False)
            row_46C02.alert = False
            row_46C02.enabled = True
            row_46C02.active = True
            row_46C02.use_property_split = False
            row_46C02.use_property_decorate = False
            row_46C02.scale_x = 1.0
            row_46C02.scale_y = 0.0
            row_46C02.alignment = 'Right'.upper()
            row_46C02.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_46C02.label(text='Handle', icon_value=0)
            split_C0A9A.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[23], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[33].default_value:
            split_D0B42 = layout.split(factor=0.4000000059604645, align=False)
            split_D0B42.alert = False
            split_D0B42.enabled = True
            split_D0B42.active = True
            split_D0B42.use_property_split = False
            split_D0B42.use_property_decorate = False
            split_D0B42.scale_x = 1.0
            split_D0B42.scale_y = 1.0
            split_D0B42.alignment = 'Center'.upper()
            if not True: split_D0B42.operator_context = "EXEC_DEFAULT"
            row_E18AE = split_D0B42.row(heading='', align=False)
            row_E18AE.alert = False
            row_E18AE.enabled = True
            row_E18AE.active = True
            row_E18AE.use_property_split = False
            row_E18AE.use_property_decorate = False
            row_E18AE.scale_x = 1.0
            row_E18AE.scale_y = 0.0
            row_E18AE.alignment = 'Right'.upper()
            row_E18AE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_E18AE.label(text='Sill', icon_value=0)
            split_D0B42.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[24], 'default_value', text='', icon_value=0, emboss=True)
        if (bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[52].default_value == 2):
            pass
        else:
            if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[48].default_value:
                split_7DC92 = layout.split(factor=0.4000000059604645, align=False)
                split_7DC92.alert = False
                split_7DC92.enabled = True
                split_7DC92.active = True
                split_7DC92.use_property_split = False
                split_7DC92.use_property_decorate = False
                split_7DC92.scale_x = 1.0
                split_7DC92.scale_y = 1.0
                split_7DC92.alignment = 'Center'.upper()
                if not True: split_7DC92.operator_context = "EXEC_DEFAULT"
                row_41F25 = split_7DC92.row(heading='', align=False)
                row_41F25.alert = False
                row_41F25.enabled = True
                row_41F25.active = True
                row_41F25.use_property_split = False
                row_41F25.use_property_decorate = False
                row_41F25.scale_x = 1.0
                row_41F25.scale_y = 0.0
                row_41F25.alignment = 'Right'.upper()
                row_41F25.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_41F25.label(text='Hindge', icon_value=0)
                split_7DC92.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[27], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[43].default_value:
            split_0336B = layout.split(factor=0.4000000059604645, align=False)
            split_0336B.alert = False
            split_0336B.enabled = True
            split_0336B.active = True
            split_0336B.use_property_split = False
            split_0336B.use_property_decorate = False
            split_0336B.scale_x = 1.0
            split_0336B.scale_y = 1.0
            split_0336B.alignment = 'Center'.upper()
            if not True: split_0336B.operator_context = "EXEC_DEFAULT"
            row_022C8 = split_0336B.row(heading='', align=False)
            row_022C8.alert = False
            row_022C8.enabled = True
            row_022C8.active = True
            row_022C8.use_property_split = False
            row_022C8.use_property_decorate = False
            row_022C8.scale_x = 1.0
            row_022C8.scale_y = 0.0
            row_022C8.alignment = 'Right'.upper()
            row_022C8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_022C8.label(text='Blinds', icon_value=0)
            split_0336B.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[26], 'default_value', text='', icon_value=0, emboss=True)
        if bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[38].default_value:
            split_9B0F6 = layout.split(factor=0.4000000059604645, align=False)
            split_9B0F6.alert = False
            split_9B0F6.enabled = True
            split_9B0F6.active = True
            split_9B0F6.use_property_split = False
            split_9B0F6.use_property_decorate = False
            split_9B0F6.scale_x = 1.0
            split_9B0F6.scale_y = 1.0
            split_9B0F6.alignment = 'Center'.upper()
            if not True: split_9B0F6.operator_context = "EXEC_DEFAULT"
            row_FB187 = split_9B0F6.row(heading='', align=False)
            row_FB187.alert = False
            row_FB187.enabled = True
            row_FB187.active = True
            row_FB187.use_property_split = False
            row_FB187.use_property_decorate = False
            row_FB187.scale_x = 1.0
            row_FB187.scale_y = 0.0
            row_FB187.alignment = 'Right'.upper()
            row_FB187.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_FB187.label(text='Blinds Box', icon_value=0)
            split_9B0F6.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[25], 'default_value', text='', icon_value=0, emboss=True)
        split_7E637 = layout.split(factor=0.4000000059604645, align=False)
        split_7E637.alert = False
        split_7E637.enabled = True
        split_7E637.active = True
        split_7E637.use_property_split = False
        split_7E637.use_property_decorate = False
        split_7E637.scale_x = 1.0
        split_7E637.scale_y = 1.0
        split_7E637.alignment = 'Center'.upper()
        if not True: split_7E637.operator_context = "EXEC_DEFAULT"
        row_5F888 = split_7E637.row(heading='', align=False)
        row_5F888.alert = False
        row_5F888.enabled = True
        row_5F888.active = True
        row_5F888.use_property_split = False
        row_5F888.use_property_decorate = False
        row_5F888.scale_x = 1.0
        row_5F888.scale_y = 0.0
        row_5F888.alignment = 'Right'.upper()
        row_5F888.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_5F888.label(text='UV Attribute', icon_value=0)
        split_7E637.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[28], 'default_value', text='', icon_value=0, emboss=True)
        split_A1CA6 = layout.split(factor=0.4000000059604645, align=False)
        split_A1CA6.alert = False
        split_A1CA6.enabled = True
        split_A1CA6.active = True
        split_A1CA6.use_property_split = False
        split_A1CA6.use_property_decorate = False
        split_A1CA6.scale_x = 1.0
        split_A1CA6.scale_y = 1.0
        split_A1CA6.alignment = 'Center'.upper()
        if not True: split_A1CA6.operator_context = "EXEC_DEFAULT"
        row_6A358 = split_A1CA6.row(heading='', align=False)
        row_6A358.alert = False
        row_6A358.enabled = True
        row_6A358.active = True
        row_6A358.use_property_split = False
        row_6A358.use_property_decorate = False
        row_6A358.scale_x = 1.0
        row_6A358.scale_y = 0.0
        row_6A358.alignment = 'Right'.upper()
        row_6A358.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_6A358.label(text='UV Scale', icon_value=0)
        split_A1CA6.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[29], 'default_value', text='', icon_value=0, emboss=True)
        split_86E88 = layout.split(factor=0.4000000059604645, align=False)
        split_86E88.alert = False
        split_86E88.enabled = True
        split_86E88.active = True
        split_86E88.use_property_split = False
        split_86E88.use_property_decorate = False
        split_86E88.scale_x = 1.0
        split_86E88.scale_y = 1.0
        split_86E88.alignment = 'Center'.upper()
        if not True: split_86E88.operator_context = "EXEC_DEFAULT"
        row_B8D19 = split_86E88.row(heading='', align=False)
        row_B8D19.alert = False
        row_B8D19.enabled = True
        row_B8D19.active = True
        row_B8D19.use_property_split = False
        row_B8D19.use_property_decorate = False
        row_B8D19.scale_x = 1.0
        row_B8D19.scale_y = 0.0
        row_B8D19.alignment = 'Right'.upper()
        row_B8D19.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_B8D19.label(text='UV Rotattion', icon_value=0)
        split_86E88.prop(bpy.context.active_object.modifiers['Windows Object'].node_group.nodes['Group'].inputs[30], 'default_value', text='', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_stored_wall_object = bpy.props.PointerProperty(name='Stored Wall Object', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_stored_bool_object = bpy.props.PointerProperty(name='Stored Bool Object', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_stored_window_object = bpy.props.PointerProperty(name='Stored Window Object', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_stored_help_object = bpy.props.PointerProperty(name='Stored Help Object', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_stored_node_group = bpy.props.StringProperty(name='Stored Node Group', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_help_bool_counter = bpy.props.IntProperty(name='Help Bool Counter', description='', default=0, subtype='NONE')
    bpy.types.Object.sna_bool_boolean = bpy.props.BoolProperty(name='Bool Boolean', description='', default=False)
    bpy.types.Scene.sna_store_start_window_obj = bpy.props.PointerProperty(name='Store Start Window Obj', description='', type=bpy.types.Object)
    bpy.types.Scene.sna_store_duplicated_window_obj = bpy.props.PointerProperty(name='Store Duplicated Window Obj', description='', type=bpy.types.Object)
    bpy.utils.register_class(RENDER_PT_Window)
    bpy.utils.register_class(SNA_OT_Make_Win_Unique_Operator_2Bf2A)
    bpy.utils.register_class(SNA_OT_Transfer_Win_Settings_Ee8D2)
    bpy.utils.register_class(SNA_OT_Apply_Holes_Ef098)
    bpy.utils.register_class(SNA_OT_Operator_Create_Holes_93634)
    bpy.utils.register_class(SNA_OT_Operator_Apply_Window_Geometry_3022E)
    bpy.utils.register_class(SNA_OT_Add_Window_Dfe99)
    bpy.utils.register_class(SNA_OT_Single_Window_70536)
    bpy.utils.register_class(SNA_OT_Show_Handle_D61Ee)
    bpy.utils.register_class(SNA_OT_Hide_Handle_6F919)
    bpy.utils.register_class(SNA_OT_Multiple_Vindows_2A7Ad)
    bpy.utils.register_class(SNA_OT_Only_Frames_A2577)
    bpy.utils.register_class(SNA_OT_Custom_Handle_C2C60)
    bpy.utils.register_class(SNA_OT_Show_Sill_A56F4)
    bpy.utils.register_class(SNA_OT_Hide_Sill_Ef647)
    bpy.utils.register_class(SNA_OT_Blinds_Random_C6Bb8)
    bpy.utils.register_class(SNA_OT_Show_Blinds_Box_4Facc)
    bpy.utils.register_class(SNA_OT_Hide_Blinds_Box_Ec951)
    bpy.utils.register_class(SNA_OT_Blinds_Same_F3622)
    bpy.utils.register_class(SNA_OT_Show_Hindge_23F0F)
    bpy.utils.register_class(SNA_OT_Hide_Hindge_133F5)
    bpy.utils.register_class(SNA_OT_Custom_Hindge_02E65)
    bpy.utils.register_class(SNA_OT_Object_Or_Collection_E2Fa7)
    bpy.utils.register_class(SNA_OT_Show_Glass_Fbe21)
    bpy.utils.register_class(SNA_OT_Hide_Glass_Ba90E)
    bpy.utils.register_class(SNA_OT_Top_Hung_Mode_75546)
    bpy.utils.register_class(SNA_OT_Turn_Mode_Dd665)
    bpy.utils.register_class(SNA_OT_Show_Blinds_E685B)
    bpy.utils.register_class(SNA_OT_Hide_Blinds_D0Bf2)
    bpy.utils.register_class(SNA_OT_Same_Angle_Bd955)
    bpy.utils.register_class(SNA_OT_Random_Angle_68279)
    bpy.utils.register_class(SNA_OT_Show_Booleans_C39Bf)
    bpy.utils.register_class(SNA_OT_Hide_Booleans_B4F87)
    bpy.utils.register_class(SNA_OT_Flip_Left_Right_70C9F)
    bpy.utils.register_class(SNA_OT_Adjust_Corner_3Ea64)
    bpy.utils.register_class(SNA_OT_Flip_Inside_Out_2Bc8C)
    bpy.utils.register_class(WINDOW_PT)
    bpy.utils.register_class(SNA_PT_WINDOW_MODE_55E55)
    bpy.utils.register_class(SNA_PT_FRAME_389A6)
    bpy.utils.register_class(SNA_PT_GLASS_DA0EE)
    bpy.utils.register_class(SNA_PT_OPENING_A5C10)
    bpy.utils.register_class(SNA_PT_HANDLE_32E97)
    bpy.utils.register_class(SNA_PT_SILL_FD474)
    bpy.utils.register_class(SNA_PT_BLINDS_A0B05)
    bpy.utils.register_class(SNA_PT_EXTRAS_735DE)
    bpy.utils.register_class(SNA_PT_WALL_HOLES_020A0)
    bpy.utils.register_class(SNA_PT_HINDGE_A5E0A)
    bpy.utils.register_class(SNA_PT_MATERIALS_A93C4)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_store_duplicated_window_obj
    del bpy.types.Scene.sna_store_start_window_obj
    del bpy.types.Object.sna_bool_boolean
    del bpy.types.Scene.sna_help_bool_counter
    del bpy.types.Scene.sna_stored_node_group
    del bpy.types.Scene.sna_stored_help_object
    del bpy.types.Scene.sna_stored_window_object
    del bpy.types.Scene.sna_stored_bool_object
    del bpy.types.Scene.sna_stored_wall_object
    bpy.utils.unregister_class(RENDER_PT_Window)
    bpy.utils.unregister_class(SNA_OT_Make_Win_Unique_Operator_2Bf2A)
    bpy.utils.unregister_class(SNA_OT_Transfer_Win_Settings_Ee8D2)
    bpy.utils.unregister_class(SNA_OT_Apply_Holes_Ef098)
    bpy.utils.unregister_class(SNA_OT_Operator_Create_Holes_93634)
    bpy.utils.unregister_class(SNA_OT_Operator_Apply_Window_Geometry_3022E)
    bpy.utils.unregister_class(SNA_OT_Add_Window_Dfe99)
    bpy.utils.unregister_class(SNA_OT_Single_Window_70536)
    bpy.utils.unregister_class(SNA_OT_Show_Handle_D61Ee)
    bpy.utils.unregister_class(SNA_OT_Hide_Handle_6F919)
    bpy.utils.unregister_class(SNA_OT_Multiple_Vindows_2A7Ad)
    bpy.utils.unregister_class(SNA_OT_Only_Frames_A2577)
    bpy.utils.unregister_class(SNA_OT_Custom_Handle_C2C60)
    bpy.utils.unregister_class(SNA_OT_Show_Sill_A56F4)
    bpy.utils.unregister_class(SNA_OT_Hide_Sill_Ef647)
    bpy.utils.unregister_class(SNA_OT_Blinds_Random_C6Bb8)
    bpy.utils.unregister_class(SNA_OT_Show_Blinds_Box_4Facc)
    bpy.utils.unregister_class(SNA_OT_Hide_Blinds_Box_Ec951)
    bpy.utils.unregister_class(SNA_OT_Blinds_Same_F3622)
    bpy.utils.unregister_class(SNA_OT_Show_Hindge_23F0F)
    bpy.utils.unregister_class(SNA_OT_Hide_Hindge_133F5)
    bpy.utils.unregister_class(SNA_OT_Custom_Hindge_02E65)
    bpy.utils.unregister_class(SNA_OT_Object_Or_Collection_E2Fa7)
    bpy.utils.unregister_class(SNA_OT_Show_Glass_Fbe21)
    bpy.utils.unregister_class(SNA_OT_Hide_Glass_Ba90E)
    bpy.utils.unregister_class(SNA_OT_Top_Hung_Mode_75546)
    bpy.utils.unregister_class(SNA_OT_Turn_Mode_Dd665)
    bpy.utils.unregister_class(SNA_OT_Show_Blinds_E685B)
    bpy.utils.unregister_class(SNA_OT_Hide_Blinds_D0Bf2)
    bpy.utils.unregister_class(SNA_OT_Same_Angle_Bd955)
    bpy.utils.unregister_class(SNA_OT_Random_Angle_68279)
    bpy.utils.unregister_class(SNA_OT_Show_Booleans_C39Bf)
    bpy.utils.unregister_class(SNA_OT_Hide_Booleans_B4F87)
    bpy.utils.unregister_class(SNA_OT_Flip_Left_Right_70C9F)
    bpy.utils.unregister_class(SNA_OT_Adjust_Corner_3Ea64)
    bpy.utils.unregister_class(SNA_OT_Flip_Inside_Out_2Bc8C)
    bpy.utils.unregister_class(WINDOW_PT)
    bpy.utils.unregister_class(SNA_PT_WINDOW_MODE_55E55)
    bpy.utils.unregister_class(SNA_PT_FRAME_389A6)
    bpy.utils.unregister_class(SNA_PT_GLASS_DA0EE)
    bpy.utils.unregister_class(SNA_PT_OPENING_A5C10)
    bpy.utils.unregister_class(SNA_PT_HANDLE_32E97)
    bpy.utils.unregister_class(SNA_PT_SILL_FD474)
    bpy.utils.unregister_class(SNA_PT_BLINDS_A0B05)
    bpy.utils.unregister_class(SNA_PT_EXTRAS_735DE)
    bpy.utils.unregister_class(SNA_PT_WALL_HOLES_020A0)
    bpy.utils.unregister_class(SNA_PT_HINDGE_A5E0A)
    bpy.utils.unregister_class(SNA_PT_MATERIALS_A93C4)
